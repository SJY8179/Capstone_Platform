package com.miniproject2_4.CapstoneProjectManagementPlatform.controller.dto;

public record UserDto(Long id, String name, String email) {}