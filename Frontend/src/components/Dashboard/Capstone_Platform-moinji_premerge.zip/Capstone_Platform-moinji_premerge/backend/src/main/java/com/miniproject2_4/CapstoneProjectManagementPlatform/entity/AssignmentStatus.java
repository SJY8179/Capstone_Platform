package com.miniproject2_4.CapstoneProjectManagementPlatform.entity;

public enum AssignmentStatus {
    ONGOING,   // DB에 이미 존재
    COMPLETED,
    PENDING
}
