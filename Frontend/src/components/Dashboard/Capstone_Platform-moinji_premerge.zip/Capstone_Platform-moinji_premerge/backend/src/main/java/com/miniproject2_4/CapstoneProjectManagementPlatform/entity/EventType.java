package com.miniproject2_4.CapstoneProjectManagementPlatform.entity;

public enum EventType {
    MEETING, DEADLINE, PRESENTATION, ETC
}
