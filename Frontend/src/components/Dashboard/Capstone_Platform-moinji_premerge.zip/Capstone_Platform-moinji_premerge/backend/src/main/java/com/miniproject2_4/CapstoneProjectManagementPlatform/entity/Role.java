package com.miniproject2_4.CapstoneProjectManagementPlatform.entity;

public enum Role {
    STUDENT, TA, PROFESSOR, ADMIN
}
