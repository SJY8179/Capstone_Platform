package com.miniproject2_4.CapstoneProjectManagementPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneProjectManagementPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
