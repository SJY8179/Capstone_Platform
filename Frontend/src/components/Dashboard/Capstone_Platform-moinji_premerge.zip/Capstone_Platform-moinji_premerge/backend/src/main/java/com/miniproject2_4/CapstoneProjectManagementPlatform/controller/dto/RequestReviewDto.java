package com.miniproject2_4.CapstoneProjectManagementPlatform.controller.dto;

public record RequestReviewDto(String message) {}