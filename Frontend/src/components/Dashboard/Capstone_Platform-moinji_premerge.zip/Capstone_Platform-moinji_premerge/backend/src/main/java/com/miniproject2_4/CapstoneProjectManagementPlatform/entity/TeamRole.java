package com.miniproject2_4.CapstoneProjectManagementPlatform.entity;

public enum TeamRole {
    LEADER,
    MEMBER
}