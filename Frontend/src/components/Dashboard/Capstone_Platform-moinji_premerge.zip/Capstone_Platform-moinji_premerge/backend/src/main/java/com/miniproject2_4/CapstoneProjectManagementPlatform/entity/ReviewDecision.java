package com.miniproject2_4.CapstoneProjectManagementPlatform.entity;

public enum ReviewDecision {
    APPROVE,
    REJECT
}